# main.py — ponto de entrada do projeto
import logging
from aiohttp import web
from config import PORT, HOST
from core.app_factory import criar_app

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("brn-p2p")


def main():
    log.info(f"Servidor iniciando em http://localhost:{PORT}")
    web.run_app(criar_app(), host=HOST, port=PORT, print=None)


if __name__ == "__main__":
    main()
