#!/usr/bin/env bash
# run.sh — inicia o servidor Carteira BRN P2P (Linux/macOS)
set -e

cd "$(dirname "$0")"

echo "============================================================"
echo "   CARTEIRA BRN P2P - Iniciando..."
echo "============================================================"
echo

# Verifica Python
if ! command -v python3 >/dev/null 2>&1; then
    echo "ERRO: python3 nao encontrado. Instale o Python 3.10+."
    exit 1
fi

# Verifica dependencias
if ! python3 -c "import aiohttp" >/dev/null 2>&1; then
    echo "Dependencias ausentes. Rodando setup.sh..."
    ./setup.sh
fi

# Verifica arquivos essenciais
for f in main.py config.py static/index.html static/app.js; do
    if [ ! -f "$f" ]; then
        echo "ERRO: Arquivo ausente: $f"
        exit 1
    fi
done

PORT="${PORT:-8080}"
echo "Servidor iniciando na porta ${PORT}..."
echo "Acesse: http://localhost:${PORT}"
echo "Para parar: Ctrl+C"
echo

python3 main.py
