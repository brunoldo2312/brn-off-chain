# Relatório de Erros — Projeto "Carteira BRN P2P"

Data da análise: 2026-09-19
Ambiente: Python 3.11.15 (Debian Linux)

Este relatório lista **todos os erros encontrados** nos arquivos enviados, com
severidade, evidência (comando/resultado) e correção sugerida. Os erros foram
**confirmados por execução real** (compilação, importação e subida do servidor),
não por suposição.

---

## Resumo executivo

O projeto contém **duas arquiteturas incompatíveis** misturadas na mesma pasta:

1. **`server.py`** — monolítico, autossuficiente (roda sozinho).
2. **`main.py` + `core/` + `handlers/` + `services/`** — modular, mas os
   arquivos estão soltos na raiz e **as pastas de pacote não existem**.

Além disso faltam arquivos essenciais (`index.html`, `app.js`, `static/`), o
`ngrok_tunnel.py` não tem a função que o `server.py` importa, e o
`requirements.txt` está incompleto. O launcher `COMEÇAR.bat` **aborta na
inicialização** porque procura arquivos que não existem.

**Resultado prático:** nenhuma das duas versões funciona "de fábrica" com os
arquivos como estão.

---

## ERROS CRÍTICOS (bloqueiam a execução)

### C1. Estrutura de pacotes ausente — `ModuleNotFoundError: No module named 'core'`

`main.py` e todos os módulos modulares importam pacotes que **não existem**:

- `main.py`: `from core.app_factory import criar_app`
- `app_factory.py`: `from core.cors import ...`, `from handlers.http_handlers import ...`,
  `from handlers.ws_handler import ...`, `from services.limpeza import ...`,
  `from services.ngrok_service import ...`, `import core.state as state`
- `http_handlers.py`: `from core.state import ...`
- `ws_handler.py`: `from core.state import ...`, `from core.rate_limit import ...`,
  `from core.validacao import ...`, `from services.broadcast import ...`
- `broadcast.py`: `from core.state import ...`
- `limpeza.py`: `from core.state import ...`, `from services.broadcast import ...`
- `rate_limit.py`: `from core.state import ...`

Mas os arquivos estão **todos na raiz** (`app_factory.py`, `cors.py`, `state.py`,
`rate_limit.py`, `validacao.py`, `http_handlers.py`, `ws_handler.py`,
`broadcast.py`, `limpeza.py`, `ngrok_service.py`) e **não existem** as pastas
`core/`, `handlers/`, `services/`.

**Evidência:**
```
$ python3 -c "import main"
ModuleNotFoundError: No module named 'core'
```

**Correção:** criar a estrutura de pastas e mover os arquivos:
```
core/__init__.py        core/app_factory.py  core/cors.py
core/state.py           core/rate_limit.py   core/validacao.py
handlers/__init__.py    handlers/http_handlers.py  handlers/ws_handler.py
handlers/ordens_handlers.py
services/__init__.py    services/broadcast.py  services/limpeza.py
services/ngrok_service.py
```
(Teste feito em cópia temporária: com a estrutura correta, `main.py` importa e
sobe normalmente.)

---

### C2. `ngrok_tunnel.py` não possui a função `abrir_tunel`

`server.py` (linha 195) faz:
```python
from ngrok_tunnel import abrir_tunel
```
Mas `ngrok_tunnel.py` só define a **classe `NgrokTunnel`** — não existe
`abrir_tunel`. O docstring do próprio `server.py` (linha 9) também menciona
`ngrok_tunnel.abrir_tunel`, que nunca foi implementada.

**Evidência (runtime real):**
```
[ERROR] [NGROK] falha ao abrir túnel: cannot import name 'abrir_tunel' from 'ngrok_tunnel'
```

**Correção:** ou adicionar a função em `ngrok_tunnel.py`:
```python
def abrir_tunel(token_file, domain_file, porta):
    token = _ler(token_file); domain = _ler(domain_file) or None
    if not token: return None
    t = NgrokTunnel(token=token, target=f"http://localhost:{porta}", domain=domain)
    return t.start()
```
ou trocar o `server.py` para usar a classe `NgrokTunnel` (como faz o
`ngrok_service.py`).

---

### C3. Arquivos estáticos ausentes — `index.html`, `app.js`, `static/`

- `config.py` define `DIR_STATIC = DIR_BUNDLE/static`, mas **não existe** a
  pasta `static/`.
- `http_handlers.index_handler` serve `static/index.html` → **404**.
- `http_handlers.app_js_handler` serve `static/app.js` → **404**.
- `server.py` serve `index.html` e `app.js` na raiz → **404** (não existem).
- Só existe `index.html.old` (ver C4).

**Evidência:**
```
$ curl -s -o /dev/null -w "%{http_code}" http://localhost:8098/       -> 404
$ curl -s -o /dev/null -w "%{http_code}" http://localhost:8098/app.js -> 404
```

**Correção:** criar `static/index.html` e `static/app.js` (ou `index.html` e
`app.js` na raiz, conforme a versão escolhida).

---

### C4. `index.html.old` NÃO é um HTML válido

O arquivo começa com um wrapper de shell heredoc:
```
cat > index.html << 'HTMLEOF'
<!DOCTYPE html>
...
HTMLEOF
```
Ou seja, é um **artefato de script** (comando de shell), não um arquivo HTML.
Se for renomeado para `index.html`, o navegador receberá a linha
`cat > index.html << 'HTMLEOF'` como texto e o HTML ficará quebrado.

**Correção:** remover as linhas `cat > index.html << 'HTMLEOF'` (primeira) e
`HTMLEOF` (última) e salvar como `index.html`/`static/index.html`.

---

### C5. `requirements.txt` incompleto — falta `aiohttp_cors`

`server.py` importa `aiohttp_cors` (linha 21), mas o `requirements.txt` só lista:
```
aiohttp>=3.9.0
pyngrok>=7.0.0
python-dotenv>=1.0.0
```
Em uma instalação limpa, `import server` falha com `ModuleNotFoundError: No
module named 'aiohttp_cors'`.

**Correção:** adicionar `aiohttp_cors>=0.7.0` ao `requirements.txt`.

---

### C6. `COMEÇAR.bat` aborta na inicialização

O launcher verifica a existência de `server.py app.js index.html`:
```bat
for %%F in (server.py app.js index.html) do (
    if not exist "%%F" (
        echo    ERRO: Arquivo ausente: %%F
        pause
        exit /b 1
    )
)
```
Como `app.js` e `index.html` **não existem**, o script imprime
`ERRO: Arquivo ausente` e encerra **antes** de subir o servidor.

**Correção:** criar os arquivos faltantes (C3/C4) ou ajustar a lista de
verificação para os nomes reais.

---

## ERROS DE CONFIGURAÇÃO / INTEGRAÇÃO

### C7. Caminho do token/domínio do ngrok inconsistente

- `config.py`:
  ```python
  NGROK_TOKEN_FILE  = os.path.join(DIR_CONFIG, "configs", "ngrok_token.txt")
  NGROK_DOMAIN_FILE = os.path.join(DIR_CONFIG, "configs", "ngrok_domain.txt")
  ```
  Espera uma pasta `configs/` que **não existe** (os arquivos estão na raiz).
- `server.py` usa `NGROK_TOKEN_FILE = "ngrok_token.txt"` (raiz) — **divergente**
  do `config.py`.

**Evidência (versão modular):**
```
[WARNING] [NGROK] Token nao encontrado - modo local apenas
```
Ou seja, o túnel nunca sobe porque o token não é encontrado no caminho esperado.

**Correção:** padronizar o caminho (usar a raiz ou criar `configs/` e mover os
arquivos).

---

### C8. Duas arquiteturas e dois modelos de dados conflitantes

- `server.py` usa estado global `ORDENS` (chave = `id` numérico), `WS_CLIENTS`,
  `RATE`, eventos `nova_ordem`/`ordem_cancelada`/`liquidacao`, rotas
  `/publicar_ordem`, `/cancelar_ordem`, `/liquidar`, `/ordens`.
- A versão modular usa `core.state.MURAL` (chave = `hash`), `CLIENTES_WS`,
  `RATE_LIMIT`, eventos `nova_ordem`/`ordem_cancelada`/`ordem_executada`,
  rotas `/api/mural`, `/health`, `/ws`.

Os contratos de API e os nomes de campos são **diferentes** entre as duas
versões. Manter as duas na mesma pasta gera confusão e risco de rodar a errada.

**Correção:** escolher **uma** arquitetura e remover a outra.

---

### C9. `python-dotenv` listado mas nunca usado

`requirements.txt` inclui `python-dotenv`, porém **nenhum** arquivo chama
`load_dotenv()`. Dependência inútil (ou falta a chamada para carregar `.env`).

---

### C10. `__init__.py` na raiz, e faltam os `__init__.py` dos pacotes

- Existe um `__init__.py` **vazio na raiz** (transforma a pasta inteira em
  pacote — desnecessário e pode causar comportamento estranho).
- Faltam `core/__init__.py`, `handlers/__init__.py`, `services/__init__.py`
  (necessários para os imports modulares).

---

## ERROS DE SEGURANÇA

### S1. Token do ngrok exposto em texto puro

`ngrok_token.txt` contém um authtoken real:
```
3J8xHeVX46aXrOZeXnKrVVFMLTr_6tcrWjc6EaxX218rXJwJ4
```
Isso é um **segredo**. Se o projeto for compartilhado/versionado, qualquer
pessoa pode usar o túnel da sua conta.

**Correção:** **revogar/rotacionar** esse token no painel do ngrok, removê-lo do
repositório, adicionar `ngrok_token.txt` ao `.gitignore` e carregá-lo via
variável de ambiente (`NGROK_TOKEN`).

### S2. CORS com `allow_credentials=True` + `Access-Control-Allow-Origin: *`

Em `server.py`, `aiohttp_cors` é configurado com `allow_credentials=True` e
origem `"*"`. Isso é **inválido** segundo a spec de CORS: navegadores rejeitam
respostas com credenciais quando a origem é curinga. Além disso, o
`cors_middleware` de `core/cors.py` ecoa a origem (`origem or "*"`) sem tratar
`Access-Control-Allow-Credentials`.

**Correção:** restringir `CORS_ORIGINS` ao domínio real do frontend e/ou não
usar `allow_credentials=True` com `*`.

---

## ERROS MENORES / QUALIDADE DE CÓDIGO

### M1. Imports não utilizados
- `server.py`: `import sys` (linha 16) nunca é usado.
- `ngrok_service.iniciar_ngrok(target, porta)`: o parâmetro `porta` **não é
  usado** dentro da função.

### M2. Rate limit sem proteção de concorrência
- `core/rate_limit.py` manipula `RATE_LIMIT` (dict global) sem lock — condição
  de corrida em ambiente assíncrono.
- `services/broadcast.py` checa `if not CLIENTES_WS` **fora** do lock.

### M3. Lógica de expiração inconsistente entre versões
- `server.py` expira ordens por `ts` + 3600 s.
- `services/limpeza.py` expira por campo `expiracao` (timestamp absoluto).
- `core/validacao.py` valida `expiracao` como timestamp absoluto.
Os critérios não batem entre si.

### M4. `validacao.py` — validação frágil de `expiracao`
Compara `int(ordem["expiracao"])` com `int(time.time())` (segundos). Se o
frontend enviar milissegundos, a ordem é considerada expirada imediatamente.
Não há checagem de unidade.

### M5. `ordens_handlers.py` é um arquivo vazio (só comentário)
Não é erro, mas é código morto que pode confundir.

### M6. `outputs/` contém arquivo residual
`outputs/workspace_output_*.txt` — artefato de execução anterior, sem relação
com o projeto.

### M7. `navegador.txt` com CRLF e caminho Windows
Contém `C:\Program Files\Google\Chrome\Application\chrome.exe\r\n`. Funciona no
Windows, mas o `\r` pode atrapalhar se lido em outros contextos.

---

## Como reproduzir os erros (comandos usados)

```bash
# 1) Sintaxe: OK (nenhum erro de sintaxe)
python3 -m py_compile *.py

# 2) Import modular: FALHA
python3 -c "import main"
# -> ModuleNotFoundError: No module named 'core'

# 3) Import do server: FALHA sem aiohttp_cors
python3 -c "import server"
# -> ModuleNotFoundError: No module named 'aiohttp_cors'

# 4) Runtime do server: FALHA no ngrok
PORT=8099 python3 server.py
# -> [ERROR] [NGROK] falha ao abrir túnel: cannot import name 'abrir_tunel'

# 5) Rotas estáticas: 404
curl -s -o /dev/null -w "%{http_code}" http://localhost:8099/       # 404
curl -s -o /dev/null -w "%{http_code}" http://localhost:8099/app.js # 404
```

---

## Plano de correção sugerido (ordem de prioridade)

1. **Escolher uma arquitetura** (recomendo a modular `main.py` + pacotes) e
   remover a outra (`server.py` ou os módulos soltos).
2. **Criar a estrutura de pastas** `core/`, `handlers/`, `services/` com os
   `__init__.py` e mover os arquivos (corrige C1).
3. **Criar `static/index.html` e `static/app.js`** (corrige C3/C4/C6).
4. **Implementar `abrir_tunel`** em `ngrok_tunnel.py` ou usar `NgrokTunnel`
   (corrige C2).
5. **Adicionar `aiohttp_cors`** ao `requirements.txt` (corrige C5).
6. **Padronizar o caminho do token** do ngrok e **rotacionar o token exposto**
   (corrige C7/S1).
7. **Restringir CORS** e remover `allow_credentials` com `*` (corrige S2).
8. Limpar imports não usados, código morto e arquivos residuais (M1–M7).
