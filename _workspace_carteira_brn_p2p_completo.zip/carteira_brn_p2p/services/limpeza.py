# services/limpeza.py
import asyncio
import logging
import time
from core.state import MURAL, LOCK
from services.broadcast import broadcast

log = logging.getLogger("brn-p2p.limpeza")


async def tarefa_limpeza(app):
    log.info("[LIMPEZA] Task iniciada")
    try:
        while True:
            await asyncio.sleep(60)
            agora = int(time.time())
            async with LOCK:
                expiradas = [h for h, o in MURAL.items()
                             if o.get("expiracao", 0) <= agora]
                for h in expiradas:
                    MURAL.pop(h, None)
            for h in expiradas:
                await broadcast({"tipo": "ordem_expirada", "hash": h})
            if expiradas:
                log.info(f"[LIMPEZA] Removidas {len(expiradas)} ordens")
    except asyncio.CancelledError:
        log.info("[LIMPEZA] Cancelada")
        raise
