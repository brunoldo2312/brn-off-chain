# services/ngrok_service.py — sobe túnel ngrok via NgrokTunnel
import logging
import os
from config import NGROK_TOKEN_FILE, NGROK_DOMAIN_FILE

log = logging.getLogger("brn-p2p.ngrok")


def _ler(caminho: str) -> str:
    if not os.path.exists(caminho):
        return ""
    with open(caminho, "r", encoding="utf-8") as f:
        return f.read().strip()


def iniciar_ngrok(target: str, porta: int):
    """
    Sobe o túnel ngrok.
    Retorna (tunel, url) em sucesso, ou (None, None) em falha.
    """
    token  = os.environ.get("NGROK_TOKEN")  or _ler(NGROK_TOKEN_FILE)
    domain = os.environ.get("NGROK_DOMAIN") or _ler(NGROK_DOMAIN_FILE) or None

    if not token:
        log.warning("[NGROK] Token nao encontrado - modo local apenas")
        return None, None

    try:
        from ngrok_tunnel import NgrokTunnel
        tunel = NgrokTunnel(token=token, target=target, domain=domain)
        url = tunel.start()
        log.info(f"[NGROK] URL publica: {url}")
        return tunel, url
    except Exception as e:
        log.error(f"[NGROK] Falha ao iniciar tunel: {e}")
        return None, None
