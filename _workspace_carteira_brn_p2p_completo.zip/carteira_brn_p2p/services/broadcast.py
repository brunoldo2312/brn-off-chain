# services/broadcast.py
import json
import logging
from core.state import CLIENTES_WS, LOCK

log = logging.getLogger("brn-p2p.broadcast")


async def broadcast(mensagem: dict):
    if not CLIENTES_WS:
        return
    payload = json.dumps(mensagem)
    async with LOCK:
        clientes = list(CLIENTES_WS)

    mortos = []
    for ws in clientes:
        try:
            await ws.send_str(payload)
        except Exception:
            mortos.append(ws)

    if mortos:
        async with LOCK:
            for ws in mortos:
                CLIENTES_WS.discard(ws)
        log.info(f"[BROADCAST] Removidos {len(mortos)} clientes mortos")
