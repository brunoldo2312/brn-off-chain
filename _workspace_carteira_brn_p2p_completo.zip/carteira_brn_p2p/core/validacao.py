# core/validacao.py
import time

CAMPOS_OBRIGATORIOS = [
    "hash", "criador", "contratoAddress",
    "valorOferecido", "valorDesejado", "expiracao",
]


def validar_ordem(ordem: dict):
    if not isinstance(ordem, dict):
        return False, "Ordem nao e um objecto"
    for campo in CAMPOS_OBRIGATORIOS:
        if campo not in ordem or not ordem[campo]:
            return False, f"Campo obrigatorio ausente: {campo}"
    end = ordem.get("contratoAddress", "")
    if not (isinstance(end, str) and end.startswith("0x") and len(end) == 42):
        return False, "contratoAddress invalido"
    try:
        if int(ordem["expiracao"]) <= int(time.time()):
            return False, "Ordem ja expirada"
    except (ValueError, TypeError):
        return False, "expiracao invalida"
    try:
        if float(ordem["valorOferecido"]) <= 0 or float(ordem["valorDesejado"]) <= 0:
            return False, "Valores devem ser positivos"
    except (ValueError, TypeError):
        return False, "Valores invalidos"
    return True, ""
