# core/cors.py
from aiohttp import web
from config import CORS_ORIGINS


@web.middleware
async def cors_middleware(request, handler):
    # Preflight (OPTIONS): responde direto, sem chamar o handler.
    if request.method == "OPTIONS":
        resp = web.Response(status=204)
    else:
        try:
            resp = await handler(request)
        except web.HTTPException as ex:
            resp = ex

    origem = request.headers.get("Origin", "")
    permitido = "*" in CORS_ORIGINS or origem in CORS_ORIGINS

    if permitido:
        # Regra da spec CORS: NÃO se pode usar "*" junto com credenciais.
        # Se a origem for curinga, ecoamos a origem real da requisição.
        if "*" in CORS_ORIGINS and origem:
            resp.headers["Access-Control-Allow-Origin"] = origem
            resp.headers["Vary"] = "Origin"
        else:
            resp.headers["Access-Control-Allow-Origin"] = origem or "*"

    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return resp
