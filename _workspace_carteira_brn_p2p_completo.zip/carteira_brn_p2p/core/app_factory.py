# core/app_factory.py
import asyncio
import logging
from aiohttp import web
from core.cors import cors_middleware
from handlers.http_handlers import (
    index_handler, app_js_handler, favicon_handler, mural_rest_handler,
    health_handler,
)
from handlers.ws_handler import ws_handler
from services.limpeza import tarefa_limpeza
from services.ngrok_service import iniciar_ngrok
from config import PORT
import core.state as state

log = logging.getLogger("brn-p2p.app")


async def iniciar_tasks(app):
    app["task_limpeza"] = asyncio.create_task(tarefa_limpeza(app))
    log.info("[STARTUP] Tasks iniciadas")

    loop = asyncio.get_event_loop()
    tunel, url = await loop.run_in_executor(
        None, iniciar_ngrok, f"http://localhost:{PORT}", PORT
    )
    state.TUNEL = tunel
    if url:
        log.warning(f"ngrok.up | public_url={url} | local=http://localhost:{PORT}")


async def parar_tasks(app):
    task = app.get("task_limpeza")
    if task:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
    if state.TUNEL:
        try:
            state.TUNEL.close()
        except Exception as e:
            log.warning(f"[SHUTDOWN] Falha fechando ngrok: {e}")
        state.TUNEL = None
    log.info("[SHUTDOWN] Encerrado")


def criar_app():
    app = web.Application(middlewares=[cors_middleware])
    app.router.add_get("/", index_handler)
    app.router.add_get("/index.html", index_handler)
    app.router.add_get("/app.js", app_js_handler)
    app.router.add_get("/favicon.svg", favicon_handler)
    app.router.add_get("/favicon.ico", favicon_handler)
    app.router.add_get("/api/mural", mural_rest_handler)
    app.router.add_get("/health", health_handler)
    app.router.add_get("/ws", ws_handler)
    app.on_startup.append(iniciar_tasks)
    app.on_cleanup.append(parar_tasks)
    return app
