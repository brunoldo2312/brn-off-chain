# core/state.py
import asyncio

MURAL: dict = {}                     # hash -> ordem
CLIENTES_WS: set = set()             # WebSocketResponse ativos
LOCK = asyncio.Lock()                # protege MURAL e CLIENTES_WS
RATE_LIMIT: dict = {}                # ip -> lista de timestamps
TUNEL = None                         # instância do NgrokTunnel
