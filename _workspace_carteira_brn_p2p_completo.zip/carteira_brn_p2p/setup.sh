#!/usr/bin/env bash
# setup.sh — instala as dependências do projeto Carteira BRN P2P
set -e

cd "$(dirname "$0")"

echo "============================================================"
echo "   CARTEIRA BRN P2P - Instalacao de dependencias"
echo "============================================================"
echo

# Verifica Python
if ! command -v python3 >/dev/null 2>&1; then
    echo "ERRO: python3 nao encontrado. Instale o Python 3.10+."
    exit 1
fi
echo "Python: $(python3 --version)"

# Verifica pip
if ! python3 -m pip --version >/dev/null 2>&1; then
    echo "ERRO: pip nao encontrado."
    exit 1
fi
echo "pip: OK"

# Instala dependencias
echo
echo "Instalando dependencias..."
python3 -m pip install -r requirements.txt

echo
echo "Dependencias instaladas com sucesso!"
echo "Para iniciar o servidor, rode: ./run.sh"
