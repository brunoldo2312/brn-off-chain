"""
Módulo de túnel NGROK para expor o servidor local na internet.
Requer: pip install pyngrok
"""
from __future__ import annotations
import logging
import os

log = logging.getLogger("brn.ngrok")


def _ler(caminho: str) -> str:
    """Lê um arquivo de texto e devolve o conteúdo sem espaços nas pontas."""
    if not caminho or not os.path.exists(caminho):
        return ""
    with open(caminho, "r", encoding="utf-8") as f:
        return f.read().strip()


class NgrokTunnel:
    def __init__(self, token: str, target: str = "http://localhost:8080",
                 domain: str | None = None):
        if not token or not token.strip():
            raise ValueError("Token NGROK vazio")
        self._token = token.strip()
        self._target = target
        self._domain = domain
        self._tunnel = None
        self._public_url = None

    def start(self) -> str:
        try:
            from pyngrok import ngrok, conf
        except ImportError as e:
            raise RuntimeError(
                "pyngrok nao instalado. Rode: pip install pyngrok"
            ) from e

        try:
            ngrok.kill()
        except Exception:
            pass

        conf.get_default().auth_token = self._token

        kwargs = {"schemes": ["https"]}
        if self._domain:
            kwargs["domain"] = self._domain

        try:
            self._tunnel = ngrok.connect(self._target, **kwargs)
        except Exception as e:
            log.error("ngrok.connect falhou: %s", e)
            raise

        self._public_url = self._tunnel.public_url

        log.warning("ngrok.up | public_url=%s | local=%s",
                    self._public_url, self._target)
        return self._public_url

    def close(self):
        if self._tunnel is not None:
            try:
                from pyngrok import ngrok
                ngrok.disconnect(self._tunnel.public_url)
                ngrok.kill()
                log.info("ngrok.down")
            except Exception as e:
                log.warning("ngrok.close_failed | err=%s", str(e))
        self._tunnel = None
        self._public_url = None

    @property
    def public_url(self) -> str | None:
        return self._public_url


def abrir_tunel(token_file: str, domain_file: str, porta: int) -> str | None:
    """
    Abre um túnel ngrok a partir dos arquivos de token/domínio.

    Compatível com a chamada feita em server.py:
        abrir_tunel(NGROK_TOKEN_FILE, NGROK_DOMAIN_FILE, 8080)

    Retorna a URL pública (str) em sucesso, ou None em falha.
    """
    token = os.environ.get("NGROK_TOKEN") or _ler(token_file)
    domain = os.environ.get("NGROK_DOMAIN") or _ler(domain_file) or None

    if not token:
        log.warning("[NGROK] Token nao encontrado - modo local apenas")
        return None

    try:
        tunel = NgrokTunnel(
            token=token,
            target=f"http://localhost:{porta}",
            domain=domain,
        )
        url = tunel.start()
        log.info("[NGROK] URL publica: %s", url)
        return url
    except Exception as e:
        log.error("[NGROK] Falha ao abrir tunel: %s", e)
        return None
