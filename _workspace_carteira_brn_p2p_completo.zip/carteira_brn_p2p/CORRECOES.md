# Correções Aplicadas — Carteira BRN P2P

Este documento lista **o que foi corrigido** em relação ao `RELATORIO_ERROS.md`.
Todas as correções foram **testadas por execução real**.

---

## ✅ Erros críticos corrigidos

| # | Erro | Correção aplicada |
|---|------|-------------------|
| C1 | Estrutura de pacotes ausente (`core/`, `handlers/`, `services/`) | Criadas as pastas com `__init__.py` e os arquivos foram movidos para os pacotes corretos. `import main` agora funciona. |
| C2 | `ngrok_tunnel.py` sem a função `abrir_tunel` | Implementada a função `abrir_tunel(token_file, domain_file, porta)` que usa a classe `NgrokTunnel`. |
| C3 | `index.html`, `app.js` e `static/` ausentes | Criados `static/index.html` e `static/app.js` completos. Rotas `/` e `/app.js` retornam **200**. |
| C4 | `index.html.old` não era HTML válido | Removido o wrapper de shell; criado HTML válido em `static/index.html`. |
| C5 | `requirements.txt` sem `aiohttp_cors` | Adicionado `aiohttp_cors>=0.7.0`. |
| C6 | `COMEÇAR.bat` abortava | Corrigido para verificar `main.py`, `config.py`, `static/index.html`, `static/app.js` e executar `python main.py`. |

## ✅ Configuração / Integração

| # | Erro | Correção aplicada |
|---|------|-------------------|
| C7 | Caminho do token ngrok inconsistente | `config.py` agora procura em `configs/` **e** na raiz (função `_achar_arquivo`). Tokens movidos para `configs/`. |
| C8 | Duas arquiteturas conflitantes | Mantida a arquitetura **modular** (`main.py` + pacotes). `server.py` monolítico removido. |
| C9 | `python-dotenv` não usado | `config.py` agora chama `load_dotenv()` (com fallback se não instalado). |
| C10 | `__init__.py` na raiz / faltavam nos pacotes | Removido o da raiz; criados `core/__init__.py`, `handlers/__init__.py`, `services/__init__.py`. |

## ✅ Segurança

| # | Erro | Correção aplicada |
|---|------|-------------------|
| S1 | Token ngrok exposto | Token movido para `configs/` (fora do versionamento). Criados `.gitignore` e `.env.example`. **Ação recomendada: rotacionar o token no painel do ngrok.** |
| S2 | CORS inválido (`credentials` + `*`) | `core/cors.py` reescrito: ecoa a origem real, adiciona `Vary: Origin`, trata preflight (204) e não usa `credentials` com `*`. |

## ✅ Menores

- Removido `import sys` não usado (o `server.py` foi removido).
- `ngrok_service.iniciar_ngrok` mantém o parâmetro `porta` (usado no target).
- `core/rate_limit.py` e `services/broadcast.py` mantidos; broadcast já usa `LOCK`.
- Padronizada a expiração por campo `expiracao` (timestamp absoluto) em `validacao.py` e `limpeza.py`.
- Removido `outputs/` residual e `__pycache__`.

---

## 🧪 Evidências de teste

```
$ python3 -m py_compile main.py config.py ngrok_tunnel.py core/*.py handlers/*.py services/*.py
SINTAXE OK

$ python3 -c "import main"
import main OK

$ python3 -c "from ngrok_tunnel import abrir_tunel"
abrir_tunel OK

# Servidor rodando:
GET /            -> 200
GET /app.js      -> 200
GET /health      -> {"status":"ok",...}
GET /api/mural   -> {"ordens":[],"total":0}
OPTIONS (CORS)   -> 204 + Access-Control-Allow-Origin: <origem>

# WebSocket:
1) snapshot: snapshot ordens: 0
2) resposta ping: pong
3) broadcast nova_ordem: nova_ordem 0xaaaaaaaa
4) erro validacao: erro - Campo obrigatorio ausente: criador
5) snapshot apos publicar: 1 ordem(ns)
6) broadcast cancelamento: ordem_cancelada
```

> Observação: o ngrok pode falhar com `ERR_NGROK_334` se o domínio
> `seventy-rigging-ploy.ngrok-free.dev` já estiver online em outra máquina.
> Nesse caso o servidor continua funcionando em modo local (http://localhost:8080).

---

## 📁 Estrutura final do projeto

```
.
├── main.py                  # ponto de entrada
├── config.py                # configurações globais
├── ngrok_tunnel.py          # classe NgrokTunnel + abrir_tunel()
├── requirements.txt
├── COMEÇAR.bat              # launcher Windows
├── .env.example             # modelo de variáveis de ambiente
├── .gitignore
├── configs/
│   ├── ngrok_token.txt      # (segredo — não versionar)
│   └── ngrok_domain.txt
├── core/
│   ├── __init__.py
│   ├── app_factory.py
│   ├── cors.py
│   ├── rate_limit.py
│   ├── state.py
│   └── validacao.py
├── handlers/
│   ├── __init__.py
│   ├── http_handlers.py
│   ├── ordens_handlers.py
│   └── ws_handler.py
├── services/
│   ├── __init__.py
│   ├── broadcast.py
│   ├── limpeza.py
│   └── ngrok_service.py
└── static/
    ├── index.html
    └── app.js
```

---

## ▶️ Como executar

### Windows
Dê duplo clique em **`COMEÇAR.bat`**.

### Linux / macOS
```bash
pip install -r requirements.txt
python main.py
```
Acesse: http://localhost:8080

### Variáveis de ambiente (opcional)
```bash
cp .env.example .env
# edite o .env com seu NGROK_TOKEN
```
