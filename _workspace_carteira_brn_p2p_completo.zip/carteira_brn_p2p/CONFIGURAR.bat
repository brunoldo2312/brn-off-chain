@echo off
setlocal EnableDelayedExpansion
title Carteira BRN P2P - Configuracao
color 0B
cd /d "%~dp0"

cls
echo.
echo ============================================================
echo    CARTEIRA BRN P2P - Configuracao do Navegador
echo ============================================================
echo.
echo    Informe o caminho completo do executavel do navegador.
echo    Exemplo: C:\Program Files\Google\Chrome\Application\chrome.exe
echo.
echo    Ou digite "padrao" para usar o navegador padrao do sistema.
echo.

set /p NAVEGADOR="Caminho do navegador: "

if "!NAVEGADOR!"=="" set NAVEGADOR=padrao

> navegador.txt echo !NAVEGADOR!

echo.
echo    Configuracao salva em navegador.txt:
echo    !NAVEGADOR!
echo.
pause
