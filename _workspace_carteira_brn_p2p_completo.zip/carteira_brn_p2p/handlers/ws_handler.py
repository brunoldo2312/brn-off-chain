# handlers/ws_handler.py
import json
import logging
import time
from aiohttp import web, WSMsgType
from core.state import MURAL, CLIENTES_WS, LOCK
from core.rate_limit import checar_rate_limit
from core.validacao import validar_ordem
from services.broadcast import broadcast

log = logging.getLogger("brn-p2p.ws")


async def ws_handler(request):
    ws = web.WebSocketResponse(heartbeat=30)
    await ws.prepare(request)
    ip = request.remote or "unknown"

    async with LOCK:
        CLIENTES_WS.add(ws)
    log.info(f"[WS] Conectado: {ip} (total={len(CLIENTES_WS)})")

    # snapshot
    agora = int(time.time())
    snapshot = [o for o in MURAL.values() if o.get("expiracao", 0) > agora]
    await ws.send_json({"tipo": "snapshot", "ordens": snapshot})

    try:
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                if msg.type == WSMsgType.ERROR:
                    log.error(f"[WS] Erro: {ws.exception()}")
                continue
            try:
                dados = json.loads(msg.data)
            except json.JSONDecodeError:
                await ws.send_json({"tipo": "erro", "msg": "JSON invalido"})
                continue

            tipo = dados.get("tipo")

            if tipo == "publicar_ordem":
                if not checar_rate_limit(ip):
                    await ws.send_json({"tipo": "erro", "msg": "Rate limit"})
                    continue
                ordem = dados.get("ordem")
                valida, erro = validar_ordem(ordem)
                if not valida:
                    await ws.send_json({"tipo": "erro", "msg": erro})
                    continue
                async with LOCK:
                    MURAL[ordem["hash"]] = ordem
                await broadcast({"tipo": "nova_ordem", "ordem": ordem})

            elif tipo == "cancelar_ordem":
                h = dados.get("hash")
                if not h:
                    await ws.send_json({"tipo": "erro", "msg": "Hash ausente"})
                    continue
                async with LOCK:
                    MURAL.pop(h, None)
                await broadcast({"tipo": "ordem_cancelada", "hash": h})

            elif tipo == "ordem_executada":
                h = dados.get("hash")
                tx = dados.get("txHash", "")
                async with LOCK:
                    MURAL.pop(h, None)
                await broadcast({"tipo": "ordem_executada",
                                 "hash": h, "txHash": tx})

            elif tipo == "pedir_snapshot":
                agora2 = int(time.time())
                snap = [o for o in MURAL.values()
                        if o.get("expiracao", 0) > agora2]
                await ws.send_json({"tipo": "snapshot", "ordens": snap})

            elif tipo == "ping":
                await ws.send_json({"tipo": "pong",
                                    "ts": int(time.time())})

    finally:
        async with LOCK:
            CLIENTES_WS.discard(ws)
        log.info(f"[WS] Desconectado: {ip} (total={len(CLIENTES_WS)})")

    return ws
