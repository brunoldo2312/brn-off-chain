# handlers/http_handlers.py
import os
import time
from aiohttp import web
from config import DIR_STATIC
from core.state import MURAL, CLIENTES_WS


async def index_handler(request):
    return web.FileResponse(os.path.join(DIR_STATIC, "index.html"))


async def app_js_handler(request):
    return web.FileResponse(
        os.path.join(DIR_STATIC, "app.js"),
        headers={"Content-Type": "application/javascript; charset=utf-8"},
    )


async def favicon_handler(request):
    return web.FileResponse(
        os.path.join(DIR_STATIC, "favicon.svg"),
        headers={"Content-Type": "image/svg+xml"},
    )


async def mural_rest_handler(request):
    agora = int(time.time())
    ativas = [o for o in MURAL.values() if o.get("expiracao", 0) > agora]
    return web.json_response({"ordens": ativas, "total": len(ativas)})


async def health_handler(request):
    from core.state import TUNEL
    public_url = TUNEL.public_url if TUNEL else None
    return web.json_response({
        "status": "ok",
        "clientes_ws": len(CLIENTES_WS),
        "ordens_ativas": len(MURAL),
        "public_url": public_url,
        "timestamp": int(time.time()),
    })
