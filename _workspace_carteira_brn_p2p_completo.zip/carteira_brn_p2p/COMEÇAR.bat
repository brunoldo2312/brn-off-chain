@echo off
setlocal EnableDelayedExpansion
title Carteira BRN P2P - Servidor
color 0A
cd /d "%~dp0"

cls
echo.
echo ============================================================
echo    CARTEIRA BRN P2P - Iniciando...
echo ============================================================
echo.

REM ----- [1/5] Verifica Python -----
echo [1/5] Verificando Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo    ERRO: Python nao encontrado!
    echo    Instale em https://www.python.org/downloads/
    echo    IMPORTANTE: marque "Add Python to PATH"
    echo.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo       Python %PYVER% OK

REM ----- [2/5] Verifica pip -----
echo [2/5] Verificando pip...
python -m pip --version >nul 2>&1
if errorlevel 1 (
    echo    ERRO: pip nao encontrado.
    pause
    exit /b 1
)
echo       pip OK

REM ----- [3/5] Verifica dependencias -----
echo [3/5] Verificando dependencias...
python -c "import aiohttp" >nul 2>&1
if errorlevel 1 (
    echo       Instalando aiohttp...
    python -m pip install aiohttp --quiet
    if errorlevel 1 (
        echo    ERRO ao instalar aiohttp.
        pause
        exit /b 1
    )
)
python -c "import aiohttp_cors" >nul 2>&1
if errorlevel 1 (
    echo       Instalando aiohttp_cors...
    python -m pip install aiohttp_cors --quiet
    if errorlevel 1 (
        echo    ERRO ao instalar aiohttp_cors.
        pause
        exit /b 1
    )
)
python -c "import pyngrok" >nul 2>&1
if errorlevel 1 (
    echo       Instalando pyngrok...
    python -m pip install pyngrok --quiet
    if errorlevel 1 (
        echo    ERRO ao instalar pyngrok.
        pause
        exit /b 1
    )
)
echo       Dependencias OK

REM ----- [4/5] Verifica arquivos -----
echo [4/5] Verificando arquivos...
for %%F in (main.py config.py static\index.html static\app.js) do (
    if not exist "%%F" (
        echo    ERRO: Arquivo ausente: %%F
        pause
        exit /b 1
    )
)
if not exist "navegador.txt" (
    echo       navegador.txt ausente - executando CONFIGURAR.BAT...
    if exist "CONFIGURAR.BAT" (
        call CONFIGURAR.BAT
    ) else (
        >navegador.txt echo padrao
    )
)
echo       Arquivos OK

REM ----- [5/5] Prepara abertura do navegador -----
echo [5/5] Preparando navegador...
set NAVEGADOR=padrao
for /f "usebackq delims=" %%L in ("navegador.txt") do set NAVEGADOR=%%L

set URL=http://localhost:8080
if exist "configs\ngrok_domain.txt" (
    for /f "usebackq delims=" %%D in ("configs\ngrok_domain.txt") do (
        if not "%%D"=="" set URL=https://%%D
    )
)

REM Cria _abrir.bat temporario que abre o navegador em 12s
> _abrir.bat echo @echo off
>>_abrir.bat echo timeout /t 12 /nobreak ^>nul
>>_abrir.bat echo if /I "!NAVEGADOR!"=="padrao" (
>>_abrir.bat echo     start "" "!URL!"
>>_abrir.bat echo ^) else ^(
>>_abrir.bat echo     if exist "!NAVEGADOR!" ^(
>>_abrir.bat echo         start "" "!NAVEGADOR!" "!URL!"
>>_abrir.bat echo     ^) else ^(
>>_abrir.bat echo         start "" "!URL!"
>>_abrir.bat echo     ^)
>>_abrir.bat echo ^)
>>_abrir.bat echo del /F /Q "%%~f0" ^>nul 2^>^&1

start "" /B cmd /C _abrir.bat

echo.
echo ============================================================
echo    Servidor iniciando na porta 8080...
echo    O navegador abrira automaticamente em ~12 segundos.
echo    Para parar: pressione Ctrl+C nesta janela.
echo ============================================================
echo.

python main.py

echo.
echo Servidor encerrado.
pause
