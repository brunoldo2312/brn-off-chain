# Carteira BRN P2P

Servidor backend assíncrono (aiohttp) + frontend web para uma carteira P2P de
tokens BRN, com mural de ordens em tempo real via WebSocket e exposição pública
automática via túnel ngrok.

---

## 📋 Índice

- [Visão geral](#-visão-geral)
- [Requisitos](#-requisitos)
- [Instalação](#-instalação)
- [Configuração](#-configuração)
- [Como executar](#-como-executar)
- [Arquitetura](#-arquitetura)
- [API](#-api)
- [WebSocket](#-websocket)
- [Segurança](#-segurança)
- [Solução de problemas](#-solução-de-problemas)

---

## 🎯 Visão geral

O projeto oferece:

- **Servidor HTTP assíncrono** (aiohttp) que serve o frontend e uma API REST.
- **Mural de ordens em tempo real** via WebSocket (`/ws`).
- **Rate limit** por IP (janela de 10 s, máx. 60 requisições).
- **Túnel ngrok automático** para expor o servidor na internet.
- **CORS** configurável.
- **Frontend** com integração MetaMask/ethers.js, QR Code e transferência de tokens.

---

## 🧰 Requisitos

- **Python 3.10+** (testado com 3.11)
- **pip**
- (Opcional) Conta no [ngrok](https://ngrok.com) para exposição pública
- (Opcional) Extensão **MetaMask** no navegador para as funções on-chain

---

## 📦 Instalação

### Windows
Dê duplo clique em **`COMEÇAR.bat`** — ele verifica o Python, instala as
dependências e inicia o servidor automaticamente.

### Linux / macOS
```bash
# 1) Instalar dependências
pip install -r requirements.txt

# 2) (Opcional) configurar variáveis de ambiente
cp .env.example .env
# edite o .env com seu NGROK_TOKEN

# 3) Iniciar
python main.py
```

Ou use o script de conveniência:
```bash
chmod +x run.sh
./run.sh
```

Acesse: **http://localhost:8080**

---

## ⚙️ Configuração

As configurações ficam em `config.py` e podem ser sobrescritas por variáveis de
ambiente (arquivo `.env`):

| Variável | Padrão | Descrição |
|----------|--------|-----------|
| `PORT` | `8080` | Porta do servidor |
| `HOST` | `0.0.0.0` | Interface de escuta |
| `NGROK_TOKEN` | — | Token de autenticação do ngrok |
| `NGROK_DOMAIN` | — | Domínio estático do ngrok (opcional) |
| `CORS_ORIGINS` | `*` | Origens permitidas (separadas por vírgula) |

### Token do ngrok
Coloque o token em **`configs/ngrok_token.txt`** ou defina a variável
`NGROK_TOKEN`. O domínio (opcional) vai em **`configs/ngrok_domain.txt`**.

> ⚠️ **Nunca** versione o `ngrok_token.txt` — ele já está no `.gitignore`.

---

## ▶️ Como executar

### Windows
```
COMEÇAR.bat
```

### Linux / macOS
```bash
python main.py
```

O servidor sobe em `http://localhost:8080`. Se o ngrok estiver configurado, uma
URL pública também é gerada e registrada no log.

---

## 🏗️ Arquitetura

```
.
├── main.py                  # ponto de entrada
├── config.py                # configurações globais
├── ngrok_tunnel.py          # classe NgrokTunnel + abrir_tunel()
├── requirements.txt
├── COMEÇAR.bat              # launcher Windows
├── CONFIGURAR.bat           # configuração do navegador (Windows)
├── run.sh                   # launcher Linux/macOS
├── setup.sh                 # instalação de dependências (Linux/macOS)
├── .env.example             # modelo de variáveis de ambiente
├── .gitignore
├── configs/
│   ├── ngrok_token.txt      # segredo — não versionar
│   └── ngrok_domain.txt
├── core/
│   ├── app_factory.py       # criação da aplicação aiohttp
│   ├── cors.py              # middleware CORS
│   ├── rate_limit.py        # controle de rate limit
│   ├── state.py             # estado em memória (mural, clientes WS)
│   └── validacao.py         # validação de ordens
├── handlers/
│   ├── http_handlers.py     # rotas HTTP
│   ├── ordens_handlers.py   # (reservado)
│   └── ws_handler.py        # handler WebSocket
├── services/
│   ├── broadcast.py         # broadcast para clientes WS
│   ├── limpeza.py           # expiração automática de ordens
│   └── ngrok_service.py     # integração com ngrok
└── static/
    ├── index.html           # interface
    └── app.js               # lógica do frontend
```

---

## 🔌 API

### `GET /`
Serve o frontend (`static/index.html`).

### `GET /app.js`
Serve o JavaScript do frontend.

### `GET /api/mural`
Retorna as ordens ativas.

```json
{ "ordens": [ ... ], "total": 0 }
```

### `GET /health`
Status do servidor.

```json
{
  "status": "ok",
  "clientes_ws": 0,
  "ordens_ativas": 0,
  "public_url": null,
  "timestamp": 1700000000
}
```

---

## 🔄 WebSocket

Conecte em `ws://<host>/ws`. Mensagens são JSON com o campo `tipo`.

### Mensagens recebidas do servidor

| `tipo` | Descrição |
|--------|-----------|
| `snapshot` | Lista completa de ordens ativas |
| `nova_ordem` | Uma ordem foi publicada |
| `ordem_cancelada` | Uma ordem foi cancelada |
| `ordem_executada` | Uma ordem foi executada |
| `ordem_expirada` | Uma ordem expirou |
| `pong` | Resposta ao `ping` |
| `erro` | Erro de validação/rate limit |

### Mensagens enviadas ao servidor

| `tipo` | Campos | Descrição |
|--------|--------|-----------|
| `publicar_ordem` | `ordem` | Publica uma nova ordem |
| `cancelar_ordem` | `hash` | Cancela uma ordem |
| `ordem_executada` | `hash`, `txHash` | Marca ordem como executada |
| `pedir_snapshot` | — | Solicita a lista atual |
| `ping` | — | Verifica a conexão |

### Formato de uma ordem
```json
{
  "hash": "0x...",
  "criador": "0x...",
  "contratoAddress": "0x...",
  "valorOferecido": "100",
  "valorDesejado": "50",
  "expiracao": 1700003600,
  "tokenOferecido": "BRN",
  "tokenDesejado": "USDC"
}
```

---

## 🔒 Segurança

- **Token do ngrok**: mantenha em `configs/ngrok_token.txt` ou no `.env`; nunca
  versione. Se vazar, **rotacione** no painel do ngrok.
- **CORS**: em produção, restrinja `CORS_ORIGINS` ao domínio exato do frontend.
- **Rate limit**: 60 requisições por 10 s por IP (ajustável em `config.py`).
- **Validação**: ordens são validadas (campos obrigatórios, endereço `0x` de 42
  caracteres, expiração futura, valores positivos).

---

## 🛠️ Solução de problemas

| Problema | Solução |
|----------|---------|
| `ModuleNotFoundError: aiohttp` | Rode `pip install -r requirements.txt` |
| Porta 8080 em uso | Defina outra: `PORT=8090 python main.py` |
| ngrok `ERR_NGROK_334` | O domínio já está online em outra máquina. Pare o outro túnel ou use outro domínio. O servidor continua em modo local. |
| Página em branco | Verifique se `static/index.html` e `static/app.js` existem |
| MetaMask não conecta | Instale a extensão e recarregue a página |

---

## 📄 Licença

Projeto fornecido como está, para uso interno.
