# config.py — configurações globais do projeto
import os
import sys

# ---------------------------------------------------------------------------
# Carrega variáveis de ambiente de um arquivo .env (se existir)
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ---------------------------------------------------------------------------
# Caminhos
# ---------------------------------------------------------------------------
if getattr(sys, "frozen", False):        # rodando como .exe (PyInstaller)
    DIR_BUNDLE = sys._MEIPASS            # arquivos embutidos (index.html, app.js)
    DIR_CONFIG = os.path.dirname(sys.executable)   # onde está o .exe (tokens)
else:                                     # rodando como .py
    DIR_BUNDLE = os.path.dirname(os.path.abspath(__file__))
    DIR_CONFIG = DIR_BUNDLE

DIR_STATIC = os.path.join(DIR_BUNDLE, "static")

# ---------------------------------------------------------------------------
# Servidor
# ---------------------------------------------------------------------------
PORT = int(os.environ.get("PORT", 8080))
HOST = os.environ.get("HOST", "0.0.0.0")

# ---------------------------------------------------------------------------
# Rate limit
# ---------------------------------------------------------------------------
RATE_JANELA = 10     # segundos
RATE_MAX = 60        # requisições por janela por IP

# ---------------------------------------------------------------------------
# Ngrok
# ---------------------------------------------------------------------------
# Procura o token/domínio primeiro em configs/, depois na raiz do projeto.
# Isso mantém compatibilidade com ambas as organizações de arquivos.
def _achar_arquivo(nome: str) -> str:
    candidatos = [
        os.path.join(DIR_CONFIG, "configs", nome),
        os.path.join(DIR_CONFIG, nome),
    ]
    for c in candidatos:
        if os.path.exists(c):
            return c
    # se nenhum existe, devolve o caminho padrão (configs/)
    return candidatos[0]


NGROK_TOKEN_FILE  = _achar_arquivo("ngrok_token.txt")
NGROK_DOMAIN_FILE = _achar_arquivo("ngrok_domain.txt")

# ---------------------------------------------------------------------------
# CORS
# ---------------------------------------------------------------------------
# Em produção, restrinja para o domínio exato do seu frontend.
# Ex.: CORS_ORIGINS = ["https://seu-dominio.ngrok-free.dev"]
CORS_ORIGINS = [o.strip() for o in os.environ.get("CORS_ORIGINS", "*").split(",") if o.strip()]
